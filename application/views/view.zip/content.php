
<div style="margin: 20px;" >

    <?php


        echo $content;



    ?>





</div>





